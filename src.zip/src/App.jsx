import './App.css'
import RouteController from "./routes/index"
function App() {

  return <RouteController/>
}

export default App
